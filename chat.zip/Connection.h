#ifndef CONNECTION_H
#define CONNECTION_H
 
#include <libpq-fe.h>
 
PGconn* conectarDB();  // Asegúrate de que este nombre coincida
 
#endif